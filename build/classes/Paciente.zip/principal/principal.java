
package principal;

import View.HomePage;


public class principal {

    public static void main(String[] args) {
        HomePage home = new HomePage();
        home.setVisible(true);
    }
    
}
