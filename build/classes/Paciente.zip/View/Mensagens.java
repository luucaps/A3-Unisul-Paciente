
package View;

public class Mensagens extends Exception{
    Mensagens(String message){
        super(message);
    }
}
